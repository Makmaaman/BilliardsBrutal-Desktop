
#!/usr/bin/env bash
# Застосування патча у Linux/macOS
# Використання: ./apply_patch_linux_mac.sh ../ПАТЧ.patch
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Використання: $0 ПАТЧ.patch"
  exit 1
fi

PATCH_FILE="$1"

if command -v git >/dev/null 2>&1; then
  git init
  git add .
  git commit -m "Baseline from src.zip" >/dev/null 2>&1 || true
  git apply "$PATCH_FILE"
  echo "[OK] Патч застосовано через git apply"
else
  if command -v patch >/dev/null 2>&1; then
    patch -p1 < "$PATCH_FILE"
    echo "[OK] Патч застосовано через GNU patch"
  else
    echo "[ПОМИЛКА] Не знайдено ні git, ні patch."
    exit 1
  fi
fi
