import React from "react";
import ModalShell from "../components/ModalShell";

export default function SettingsModal({
  onClose,
  espIP, setEspIP,
  mockMode, setMockMode,
  printerIP, setPrinterIP,
  printerMock, setPrinterMock,
  tables, relays, setRelays,
  bonusEarnPct, setBonusEarnPct,
  bonusPerHour, setBonusPerHour,
  onTestPrint
}) {
  return (
    <ModalShell title="Налаштування" onClose={onClose} footer={
      <div className="flex justify-end gap-2">
        <button className="h-9 px-4 rounded-lg bg-slate-800 text-white" onClick={onClose}>Готово</button>
      </div>
    }>
      <div className="grid md:grid-cols-2 gap-6">
        <section className="space-y-3">
          <div className="text-sm font-medium">ESP контролер</div>
          <label className="block text-xs text-slate-500">IP-адреса</label>
          <input className="w-full h-9 px-2 rounded-lg ring-1 ring-slate-200" value={espIP || ""} onChange={e=>setEspIP(e.target.value)} />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={!!mockMode} onChange={e=>setMockMode(e.target.checked)} />
            Працювати в режимі «mock» (без реального реле)
          </label>
        </section>

        <section className="space-y-3">
          <div className="text-sm font-medium">Принтер чеків</div>
          <label className="block text-xs text-slate-500">IP-адреса принтера</label>
          <input className="w-full h-9 px-2 rounded-lg ring-1 ring-slate-200" value={printerIP || ""} onChange={e=>setPrinterIP(e.target.value)} />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={!!printerMock} onChange={e=>setPrinterMock(e.target.checked)} />
            Режим «збереження у файл» (mock)
          </label>
          <button className="mt-2 h-9 px-3 rounded-lg bg-sky-600 text-white hover:brightness-110" onClick={onTestPrint}>Тестовий друк</button>
        </section>
      </div>

      <div className="mt-6">
        <div className="text-sm font-medium mb-2">Відповідність «Стіл → канал реле»</div>
        <div className="grid md:grid-cols-2 gap-3">
          {tables.map(t => (
            <div key={t.id} className="flex items-center justify-between gap-3 rounded-lg ring-1 ring-slate-200 px-3 py-2">
              <div className="text-sm">{t.name}</div>
              <div className="flex items-center gap-2 text-sm">
                <span className="text-slate-500">Канал:</span>
                <input
                  type="number"
                  className="W-20 h-8 px-2 rounded-lg ring-1 ring-slate-200"
                  value={relays[t.id] ?? 0}
                  onChange={e=>{
                    const val = Number(e.target.value);
                    setRelays(prev => ({ ...(prev||{}), [t.id]: isNaN(val) ? 0 : val }));
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Бонуси */}
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <section className="space-y-2">
          <div className="text-sm font-medium">Бонусна програма</div>

          <label className="block text-xs text-slate-500">Нарахування бонусів за час (грн/год)</label>
          <input
            type="number"
            className="w-40 h-9 px-2 rounded-lg ring-1 ring-slate-200"
            value={bonusPerHour ?? 0}
            onChange={e=>setBonusPerHour(Number(e.target.value)||0)}
            min={0}
            step={0.5}
          />
          <div className="text-xs text-slate-500">
            Якщо &gt; 0 — бонуси нараховуються за годину навіть при грі за бонуси.
          </div>

          <div className="h-3" />

          <label className="block text-xs text-slate-500">% від нетто-суми (якщо грн/год = 0)</label>
          <input
            type="number"
            className="w-32 h-9 px-2 rounded-lg ring-1 ring-slate-200"
            value={bonusEarnPct ?? 0}
            onChange={e=>setBonusEarnPct(Number(e.target.value)||0)}
            min={0}
            step={0.5}
          />
        </section>
      </div>
    </ModalShell>
  );
}

/* =======================
 * Модал «Статистика»
 * ======================= */
