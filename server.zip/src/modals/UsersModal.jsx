import React, { useState } from "react";
import ModalShell from "../components/ModalShell";

export default function UsersModal({ users, me, onClose, onAdd, onRemove, onResetPwd }) {
  const [login, setLogin] = useState("");
  const [pwd, setPwd]     = useState("");
  const [role, setRole]   = useState("marker");
  const [newPwd, setNewPwd] = useState("");

  return (
    <ModalShell title="Користувачі" onClose={onClose} footer={
      <div className="text-right">
        <button className="h-9 px-4 rounded-lg bg-slate-800 text-white" onClick={onClose}>Готово</button>
      </div>
    }>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end mb-4">
        <div>
          <label className="block text-xs text-slate-500 mb-1">Логін</label>
          <input className="w-full h-9 px-2 rounded-lg ring-1 ring-slate-200 focus:outline-none" value={login} onChange={e=>setLogin(e.target.value)} />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Пароль</label>
          <input className="w-full h-9 px-2 rounded-lg ring-1 ring-slate-200 focus:outline-none" value={pwd} onChange={e=>setPwd(e.target.value)} />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Роль</label>
          <select className="w-full h-9 px-2 rounded-lg ring-1 ring-slate-200" value={role} onChange={e=>setRole(e.target.value)}>
            <option value="marker">marker</option>
            <option value="admin">admin</option>
          </select>
        </div>
        <div>
          <button className="w-full h-9 rounded-lg bg-emerald-600 text-white hover:brightness-110"
            onClick={() => { onAdd({ username:login.trim(), password:pwd.trim(), role }); setLogin(""); setPwd(""); setRole("marker"); }}
          >
            Додати користувача
          </button>
        </div>
      </div>

      <div className="divide-y divide-slate-200 rounded-lg ring-1 ring-slate-200 overflow-hidden">
        {users.map(u => (
          <div key={u.username} className="px-3 py-2 flex items-center gap-3 bg-white">
            <div className="w-7 h-7 rounded-full bg-slate-100 grid place-items-center text-xs">{u.username.slice(0,2).toUpperCase()}</div>
            <div className="flex-1">
              <div className="text-sm font-medium">{u.username} {u.username===me && <span className="text-[10px] text-emerald-600 ml-1">(це ви)</span>}</div>
              <div className="text-[11px] text-slate-500">роль: {u.role}</div>
            </div>
            <input placeholder="новий пароль" className="h-8 px-2 rounded-lg ring-1 ring-slate-200 text-sm"
              value={u.username===me ? "" : newPwd} onChange={e=>setNewPwd(e.target.value)}
              disabled={u.username===me}
              title={u.username===me ? "Не можна змінити пароль тут для поточного користувача" : "Введіть новий пароль та натисніть «OK»"}
            />
            <button className="h-8 px-2 rounded-lg bg-sky-600 text-white text-sm hover:brightness-110 disabled:opacity-50"
              onClick={()=>{ if (!newPwd) return; onResetPwd(u.username, newPwd); setNewPwd(""); }}
              disabled={u.username===me}
            >OK</button>
            <button className="h-8 px-2 rounded-lg bg-rose-600 text-white text-sm hover:brightness-110 disabled:opacity-50"
              onClick={()=>onRemove(u.username)}
              disabled={u.username==="admin" || u.username===me}
              title={u.username==="admin" ? "admin видаляти не можна" : ""}
            >
              Видалити
            </button>
          </div>
        ))}
      </div>
    </ModalShell>
  );
}

/* =======================
 * Модал «Перевірити оновлення»
 * ======================= */
