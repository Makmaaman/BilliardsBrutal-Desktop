import React, { useRef, useState } from "react";
import { snapToStep, clamp, MIN_MS, MS_IN_MIN } from "./reservationUtils";

export default function TimelineGrid({ stepMin, nowTick }) {
  const [drag, setDrag] = useState(null);
  const gridRef = useRef(null);
  const stepMs = stepMin * MS_IN_MIN;

  // Placeholder reservations array — replace with your data source or context
  const reservations = [
    // example:
    // { id: 'r1', startMs: 8*60*MS_IN_MIN, endMs: 9*60*MS_IN_MIN }
  ];

  const openEdit = (resv) => {
    // implement opening edit drawer/modal
    console.log("openEdit", resv);
  };

  const onBlockMouseDown = (e, resv, handle) => {
    if (e.target.closest && e.target.closest(".rsv-edit-btn")) return;
    e.preventDefault();
    e.stopPropagation();
    const type = handle || "move";
    setDrag({
      id: resv.id,
      type,
      startMs: resv.startMs,
      endMs: resv.endMs,
      offset: e.clientY,
    });
  };

  const onMouseMove = (e) => {
    if (!drag) return;
    const deltaPx = e.clientY - drag.offset;
    const pxPerStep = 8;
    const stepsDelta = Math.round(deltaPx / pxPerStep);
    const deltaMs = stepsDelta * stepMs;

    let newStart = drag.startMs;
    let newEnd = drag.endMs;

    if (drag.type === "move") {
      newStart = snapToStep(drag.startMs + deltaMs, stepMs);
      newEnd = snapToStep(drag.endMs + deltaMs, stepMs);
    } else if (drag.type === "resize") {
      newEnd = snapToStep(drag.endMs + deltaMs, stepMs);
      newEnd = Math.max(newEnd, newStart + MIN_MS);
    }

    const DAY_START = 8 * 60 * MS_IN_MIN;
    const DAY_END = 26 * 60 * MS_IN_MIN;

    newStart = clamp(newStart, DAY_START, DAY_END - MIN_MS);
    newEnd = clamp(newEnd, newStart + MIN_MS, DAY_END);

    // TODO: update reservation in your store/context here
    // console.log('drag update', drag.id, newStart, newEnd);
  };

  const onMouseUp = () => setDrag(null);

  return (
    <div
      className="rsv-timeline"
      ref={gridRef}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      style={{ position: "relative", minHeight: 720 }}
    >
      <div className="rsv-now-line" style={{ top: calcNowTop(nowTick) }} />

      {reservations.map((resv) => (
        <div
          key={resv.id}
          className="rsv-block"
          style={{
            top: msToTop(resv.startMs),
            height: msToHeight(resv.endMs - resv.startMs),
          }}
          onMouseDown={(e) => onBlockMouseDown(e, resv, "move")}
        >
          <button
            className="rsv-edit-btn"
            onMouseDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation();
              openEdit(resv);
            }}
          >
            Редагувати
          </button>

          <div
            className="rsv-resize-handle"
            onMouseDown={(e) => onBlockMouseDown(e, resv, "resize")}
          />
        </div>
      ))}
    </div>
  );
}

function calcNowTop(now) {
  // Placeholder: adapt to your grid scale
  return 120;
}

function msToTop(ms) {
  return Math.round(ms / (5 * 60 * 1000)) * 8;
}

function msToHeight(ms) {
  return Math.max(8, Math.round(ms / (5 * 60 * 1000)) * 8);
}
