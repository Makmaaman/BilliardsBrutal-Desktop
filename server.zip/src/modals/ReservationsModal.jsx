import React, { useEffect, useState } from "react";
import ModalShell from "../components/ModalShell";
import LeftCalendar from "./reservations/LeftCalendar";
import TimelineGrid from "./reservations/TimelineGrid";
import { loadStep, saveStep } from "./reservations/reservationUtils";
import "../styles/reservations.css";

const STEP_OPTIONS = [5, 10, 15, 30];

export default function ReservationsModal({ isOpen, onClose }) {
  const [stepMin, setStepMin] = useState(loadStep());
  const [nowTick, setNowTick] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNowTick(Date.now()), 60 * 1000);
    return () => clearInterval(id);
  }, []);

  const onChangeStep = (e) => {
    const v = Number(e.target.value) || 15;
    setStepMin(v);
    saveStep(v);
  };

  if (!isOpen) return null;

  return (
    <ModalShell open={isOpen} onClose={onClose} wide>
      <div className="rsv-header">
        <div className="rsv-title">Бронювання</div>
        <div className="rsv-controls">
          <label className="rsv-control">
            <span>Крок часу:</span>
            <select value={stepMin} onChange={onChangeStep}>
              {STEP_OPTIONS.map((m) => (
                <option key={m} value={m}>
                  {m} хв
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      <div className="rsv-body">
        <aside className="rsv-left">
          <LeftCalendar nowTick={nowTick} />
        </aside>
        <main className="rsv-main">
          <TimelineGrid stepMin={stepMin} nowTick={nowTick} />
        </main>
      </div>
    </ModalShell>
  );
}
