// src/components/ReservationsTicker.jsx
import React, { useMemo, useEffect, useState } from "react";
import { useReservations, RES_STATUSES } from "../hooks/useReservations";
import { useTicker } from "../hooks/useTicker";
import { fmtDT } from "../utils/reservationUtils";

const UI_RES_TICKER_COLLAPSED = "UI_RES_TICKER_COLLAPSED_V1";

/**
 * Віджет актуальних бронювань із можливістю згорнути/розгорнути.
 * Код бронювання тепер показує лише «дата-стіл», а повний унікальний код — у tooltip.
 */
export default function ReservationsTicker({ tables = [], onOpenReservations, soonWithinMins = 30 }) {
  useTicker(true, 60_000);

  // миттєва реакція на глобальні зміни
  const [, force] = useState(0);
  useEffect(() => {
    const onChanged = () => force((v) => v + 1);
    window.addEventListener("reservations:changed", onChanged);
    return () => window.removeEventListener("reservations:changed", onChanged);
  }, []);

  const now = Date.now();
  const { list } = useReservations();

  const tableName = (tableId) => {
    const t = (tables || []).find((x) => String(x?.id) === String(tableId));
    return t?.name || `Стіл ${tableId}`;
  };
  const who = (r) => {
    const s = [r?.customer1Name, r?.customer2Name].filter(Boolean).join(" & ");
    const name = s || r?.name || "Гість";
    return String(name);
  };
  const mins = (ms) => Math.max(0, Math.round(ms / 60000));
  const plural = (n, forms) => (n === 1 ? forms[0] : forms[1]);

  const safeList = Array.isArray(list) ? list : [];

  const ongoing = useMemo(() => {
    return safeList
      .filter((r) => r && r.status !== RES_STATUSES.CANCELLED)
      .filter((r) => {
        const s = new Date(r.startAt).getTime();
        const e = new Date(r.endAt).getTime();
        return r.status === RES_STATUSES.IN_PROGRESS || (Number.isFinite(s) && Number.isFinite(e) && s <= now && now < e);
      })
      .sort((a, b) => new Date(a.endAt) - new Date(b.endAt));
  }, [safeList, now]);

  const upcoming = useMemo(() => {
    const horizon = now + soonWithinMins * 60_000;
    return safeList
      .filter((r) => r && r.status === RES_STATUSES.BOOKED)
      .filter((r) => {
        const s = new Date(r.startAt).getTime();
        return Number.isFinite(s) && s >= now && s <= horizon;
      })
      .sort((a, b) => new Date(a.startAt) - new Date(b.startAt));
  }, [safeList, now, soonWithinMins]);

  // ---- Collapsible (persist) ----
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem(UI_RES_TICKER_COLLAPSED) === "1"; } catch { return false; }
  });
  useEffect(() => {
    try { localStorage.setItem(UI_RES_TICKER_COLLAPSED, collapsed ? "1" : "0"); } catch {}
  }, [collapsed]);

  if (!ongoing.length && !upcoming.length && collapsed) return null;

  const ongoingLbl = `${plural(ongoing.length, ["йде", "йдуть"])}: ${ongoing.length}`;
  const upcomingLbl = `скоро: ${upcoming.length}`;

  function parseCode(code) {
    if (typeof code !== "string") return { label: "", full: "" };
    const m = code.match(/^(\d{2}\.\d{2})-(\d{2})-([a-zA-Z0-9]{2,})$/);
    if (m) {
      return { label: `${m[1]}-${m[2]}`, full: code };
    }
    // fallback — показати як є, але теж не переносити
    return { label: code, full: code };
  }

  const CodeBadge = ({ code }) => {
    if (!code) return null;
    const { label, full } = parseCode(code);
    return (
      <span
        className="ml-3 shrink-0 inline-flex items-center px-2 py-0.5 rounded-md border border-slate-200 bg-slate-50 text-slate-700 text-[11px] font-mono tracking-wide whitespace-nowrap"
        title={`Код бронювання: ${full}`}
      >
        {label}
      </span>
    );
  };

  return (
    <section className="max-w-7xl mx-auto px-4 mt-3">
      <div className="rounded-2xl ring-1 ring-slate-200 bg-white overflow-hidden shadow-sm">
        {/* Header */}
        <div className="flex items-center justify-between px-3 py-2 md:px-4 md:py-3 border-b border-slate-200/80">
          <div className="font-semibold">Бронювання</div>
          <div className="flex items-center gap-2">
            <div className="text-xs text-slate-500">{ongoingLbl} • {upcomingLbl}</div>
            <button
              type="button"
              aria-label={collapsed ? "Показати віджет бронювання" : "Сховати віджет бронювання"}
              aria-expanded={!collapsed}
              onClick={() => setCollapsed((v) => !v)}
              className="h-8 w-8 grid place-items-center rounded-full ring-1 ring-slate-200 hover:bg-slate-100 transition-colors"
            >
              <svg
                viewBox="0 0 24 24"
                className={`h-4 w-4 transition-transform duration-300 ${collapsed ? "-rotate-90" : "rotate-90"}`}
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M9 6l6 6-6 6" />
              </svg>
            </button>
          </div>
        </div>

        {/* Collapsible */}
        <div className={`grid transition-[grid-template-rows] duration-500 ease-in-out ${collapsed ? "grid-rows-[0fr]" : "grid-rows-[1fr]"}`}>
          <div className="overflow-hidden">
            <div className="p-3 md:p-4">
              <div className="grid md:grid-cols-2 gap-3">
                {/* Йдуть зараз */}
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-3">
                  <div className="text-xs font-medium text-emerald-900 mb-2">Йдуть зараз</div>
                  {ongoing.length === 0 ? (
                    <div className="text-sm text-emerald-900/80">Немає активних бронювань.</div>
                  ) : (
                    <div className="flex flex-col gap-2">
                      {ongoing.map((r, i) => {
                        const end = new Date(r.endAt).getTime();
                        const left = Math.max(0, end - now);
                        const leftMin = mins(left);
                        return (
                          <div
                            key={r.id}
                            className="flex items-center justify-between rounded-lg bg-white border border-emerald-200 px-3 py-2 transition duration-300"
                            style={{ transitionDelay: `${i * 25}ms` }}
                          >
                            <div className="min-w-0">
                              <div className="text-sm font-medium text-slate-800 truncate">{who(r)}</div>
                              <div className="text-xs text-slate-500">
                                {tableName(r.tableId)} • до {fmtDT(r.endAt)} • {leftMin <= 0 ? "менше хвилини" : `ще ${leftMin} хв`}
                              </div>
                            </div>
                            <CodeBadge code={r?.code} />
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Скоро почнуться */}
                <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-3">
                  <div className="text-xs font-medium text-sky-900 mb-2">Скоро почнуться (≤ {soonWithinMins} хв)</div>
                  {upcoming.length === 0 ? (
                    <div className="text-sm text-sky-900/80">Найближчих бронювань немає.</div>
                  ) : (
                    <div className="flex flex-col gap-2">
                      {upcoming.map((r, i) => {
                        const start = new Date(r.startAt).getTime();
                        const etaMs = Math.max(0, start - now);
                        const etaMin = mins(etaMs);
                        return (
                          <div
                            key={r.id}
                            className="flex items-center justify-between rounded-lg bg-white border border-sky-200 px-3 py-2 transition duration-300"
                            style={{ transitionDelay: `${i * 25}ms` }}
                          >
                            <div className="min-w-0">
                              <div className="text-sm font-medium text-slate-800 truncate">{who(r)}</div>
                              <div className="text-xs text-slate-500">
                                {tableName(r.tableId)} • о {fmtDT(r.startAt)} • {etaMin <= 0 ? "менше хвилини" : `через ${etaMin} хв`}
                              </div>
                            </div>
                            <CodeBadge code={r?.code} />
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end mt-3">
                <button
                  type="button"
                  className="h-9 px-3 rounded-lg bg-slate-900 text-white hover:brightness-110"
                  onClick={onOpenReservations}
                >
                  Всі бронювання
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
