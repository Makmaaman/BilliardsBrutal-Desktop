// src/components/ModalShell.jsx
import React, { useEffect, useRef } from "react";
import { createPortal } from "react-dom";

export default function ModalShell({
  open,
  onClose,
  title,
  children,
  maxWidth = 1600,         // 👈 ширина модального вікна (px)
  maxHeightVh = 90,        // висота як % від вікна
}) {
  const dialogRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose?.();
    };
    document.addEventListener("keydown", onKey);
    // блокувати скрол сторінки під модалкою
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center"
      aria-modal="true"
      role="dialog"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"
        onClick={onClose}
      />

      {/* Dialog */}
      <div
        ref={dialogRef}
        className="relative bg-white shadow-2xl rounded-2xl ring-1 ring-slate-200 flex flex-col"
        style={{
          width: `min(98vw, ${maxWidth}px)`,   // 👈 ширше вікно
          maxHeight: `${maxHeightVh}vh`,
        }}
        onClick={(e) => e.stopPropagation()}   // не закривати при кліку всередині
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-200">
          <h3 className="text-base font-semibold text-slate-900">{title}</h3>
          <button
            onClick={onClose}
            className="h-8 w-8 grid place-items-center rounded-lg hover:bg-slate-100"
            aria-label="Закрити"
          >
            <span className="text-xl leading-none">×</span>
          </button>
        </div>

        {/* Body (скролиться) */}
        <div className="p-4 overflow-auto">{children}</div>
      </div>
    </div>,
    document.body
  );
}
