# CHANGELOG — 2025-10-04 TopBar Redesign

- Повністю оновлено `TopBar.jsx` у стилі «скло + світлові акценти».
- Додано плавну верхню «світлову» лінію з анімацією градієнта.
- Перероблено блок бренду: круглий логотип **DB** залишено, додано м’який пульс при активному `liveBadge`.
- Чіпи-статуси отримали кращу читабельність, легку появу (stagger-in) і пульс для активних станів.
- Кнопки дій: нові стилі, легкий натиск (press) і wiggle-анімація для меню.
- У `index.css` додані keyframes та утиліти: `gradientSlide`, `softPulse`, `fadeUp`, `wiggle`, `marquee`.
- Збережено повну сумісність пропсів: `user`, `role`, `baseRate`, `espIp`, `espOnline`, `licenseInfo`, `version`, `liveBadge`, `onOpenMenu`, `onAddTable`, `onRemoveTable`, `onFeedback`.
