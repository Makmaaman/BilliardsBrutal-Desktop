// src/utils/receipt.js
let costForInterval = null;
try {
  ({ costForInterval } = await import('./tariffs.js'));
} catch (_e) { costForInterval = null; }

function pad2(n){ return String(n).padStart(2,'0'); }
function fmtDate(d){ return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`; }
function fmtTime(d){ return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; }
function money(v){ const n = Number(v) || 0; return n.toFixed(2); }

function computeGameCost(table, tariffs){
  const intervals = Array.isArray(table?.intervals) ? table.intervals : [];
  let sum = 0;
  if (costForInterval) {
    for (const it of intervals) {
      const from = Number(it?.from) || 0;
      const to = Number(it?.to) || Date.now();
      sum += Number(costForInterval({ from, to }, tariffs) || 0);
    }
  }
  return { intervals, sum };
}

function buildCueLines(table, cues){
  const rentals = table?.rentals && typeof table.rentals === 'object' ? table.rentals : {};
  const cueMap = new Map();
  if (Array.isArray(cues)) {
    for (const c of cues) cueMap.set(String(c?.id ?? c?.slug ?? c?.name), c);
  } else if (cues && typeof cues === 'object') {
    for (const [k, v] of Object.entries(cues)) cueMap.set(String(k), v);
  }
  const countByCue = new Map();
  for (const pid of Object.keys(rentals)) {
    const cid = String(rentals[pid] ?? '');
    if (!cid) continue;
    countByCue.set(cid, (countByCue.get(cid) || 0) + 1);
  }
  const lines = [];
  let sum = 0;
  for (const [cid, qty] of countByCue.entries()) {
    const cue = cueMap.get(cid);
    const name = cue?.name || `Кий ${cid}`;
    const price = Number(cue?.price ?? cue?.pricePerHour ?? 0);
    const lineRight = price > 0 ? money(price * qty) : '';
    const qtyStr = qty > 1 ? ` x${qty}` : '';
    const base = `Оренда кия${qtyStr} ${name}`.trim();
    const padLen = 28 - base.length;
    const pad = padLen > 1 ? ' '.repeat(padLen) : ' ';
    lines.push(`${base}${pad}${lineRight}`.trimEnd());
    sum += price * qty;
  }
  return { lines, sum };
}

export function buildReceiptText({
  table,
  tariffs,
  cues,
  title = 'Більярдний клуб',
  tableLabel,
  operatorName = 'Адміністратор'
} = {}) {
  const now = new Date();
  const dateStr = fmtDate(now);
  const timeStr = fmtTime(now);
  const tableName = tableLabel || `№${table?.id ?? ''}`;

  const game = computeGameCost(table, tariffs);
  const gameLineBase = `Гра`;
  const gameRight = money(game.sum);
  const gamePadLen = 28 - gameLineBase.length;
  const gamePad = gamePadLen > 1 ? ' '.repeat(gamePadLen) : ' ';
  const gameLine = `${gameLineBase}${gamePad}${gameRight}`.trimEnd();

  let cuesSource = cues;
  if (!cuesSource) {
    try {
      const raw = localStorage.getItem('bb_cues_v1');
      if (raw) cuesSource = JSON.parse(raw);
    } catch (_e) {}
  }
  const cue = buildCueLines(table, cuesSource);

  const total = Number(game.sum) + Number(cue.sum);

  const lines = [];
  lines.push(title);
  lines.push(`Дата: ${dateStr} ${timeStr}`);
  lines.push(`Стіл: ${tableName}  Оператор: ${operatorName}`);
  lines.push('------------------------------');
  lines.push(gameLine);
  if (cue.lines.length) for (const l of cue.lines) lines.push(l);
  lines.push('------------------------------');
  lines.push(`СУМА: ${money(total)}`);

  const text = lines.join('\n');
  return { text, total, lines };
}
