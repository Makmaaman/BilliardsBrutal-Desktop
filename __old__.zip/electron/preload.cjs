// electron/preload.cjs — Patch v33
const { contextBridge, ipcRenderer } = require("electron");
const invoke = (ch, payload) => ipcRenderer.invoke(ch, payload);

contextBridge.exposeInMainWorld("versions", { app: () => "dev" });
contextBridge.exposeInMainWorld("machine", { id: () => invoke("machine:getId") });

contextBridge.exposeInMainWorld("license", {
  getStatus: () => invoke("license:getStatus"),
  openPayment: (payload) => invoke("license:openPayment", payload || {}),
  refreshOrder: (orderId, apiBase) => invoke("license:refreshOrder", { orderId, apiBase }),
  activate: (machineId, orderId, apiBase) => invoke("license:activate", { machineId, orderId, apiBase }),
  clearOrder: () => invoke("license:clearOrder"),
  applyJwt: (jwt, meta) => invoke("license:applyJwt", { jwt, meta }),
  getApiBase: () => invoke("license:getApiBase"),
  setApiBase: (base) => invoke("license:setApiBase", { base }),
  activated: () => invoke("license:activated"),
  deactivate: () => invoke("license:deactivate"),
  ping: () => invoke("license:ping"),
});
