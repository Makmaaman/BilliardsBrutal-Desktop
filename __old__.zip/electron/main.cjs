// electron/main.cjs — Patch v33 (authoritative, includes all license handlers)
// - Fixed getStatus: ok=false when no license or expired sub
// - Hardcoded API base
// - HTTP via electron.net
/* eslint-disable no-console */
const path = require("path");
const { app, BrowserWindow, ipcMain, shell, net } = require("electron");
const os = require("os");
const crypto = require("crypto");
const fs = require("fs");

const HARD_BASE = "https://billiardsbrutal-desktop-1.onrender.com";
const LIC_DIR = app.getPath("userData");
const LIC_JSON = path.join(LIC_DIR, "license.json");
const LIC_JWT  = path.join(LIC_DIR, "license.jwt");

// === PRINT: HTML через системний принтер (обов'язково)
const { registerReceiptPrinting } = require("./receiptPrinter.cjs");

// === PRINT: ESC/POS по TCP:9100 (опціонально; якщо файл є)
let registerEscposPrinting = null;
try { ({ registerEscposPrinting } = require("./escpos.cjs")); } catch (e) { /* optional */ }

const isDev = !!process.env.VITE_DEV_SERVER_URL;

let mainWindow = null;
let paymentWindow = null;

// ---------- helpers ----------
function computeMachineId() {
  try {
    const nets = os.networkInterfaces();
    const macs = Object.values(nets).flat().filter(Boolean).map(n => n.mac).filter(m => m && m !== "00:00:00:00:00:00").sort().join("|");
    const seed = [os.hostname(), os.arch(), os.platform(), macs, process.execPath, app.getPath("userData")].join("#");
    return crypto.createHash("sha256").update(seed).digest("hex").slice(0, 32);
  } catch {
    return crypto.createHash("sha256").update(os.hostname() + (process.env.USER || "unknown")).digest("hex").slice(0, 32);
  }
}
function readLicenseToken() {
  try {
    const raw = fs.readFileSync(LIC_JSON, "utf-8").trim();
    if (raw) {
      try { const o = JSON.parse(raw); if (o && o.jwt) return String(o.jwt); } catch {}
      if (/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/.test(raw)) return raw;
    }
  } catch {}
  try { const raw = fs.readFileSync(LIC_JWT, "utf-8").trim(); if (raw) return raw; } catch {}
  return null;
}
function writeLicenseToken(jwt) {
  const token = String(jwt || "").trim();
  if (!token) throw new Error("Empty license token");
  fs.writeFileSync(LIC_JSON, JSON.stringify({ jwt: token }, null, 2), "utf-8");
  fs.writeFileSync(LIC_JWT, token, "utf-8");
  return token;
}
function decodeJwtPayload(token){
  try{
    const p = String(token||"").split(".")[1];
    if (!p) return null;
    const pad = (s)=> s + "=".repeat((4 - s.length % 4) % 4);
    const json = Buffer.from(pad(p).replace(/-/g,"+").replace(/_/g,"/"), "base64").toString("utf-8");
    return JSON.parse(json);
  }catch{ return null; }
}
function httpJson(method, url, body) {
  return new Promise((resolve, reject) => {
    try {
      const request = net.request({ method, url });
      request.setHeader("Content-Type", "application/json");
      const timer = setTimeout(() => { try { request.abort(); } catch {} ; reject(new Error("NETWORK_TIMEOUT")); }, 20000);
      request.on("response", (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => {
          clearTimeout(timer);
          const text = Buffer.concat(chunks).toString("utf-8");
          let json = null; try { json = JSON.parse(text || "{}"); } catch {}
          if (res.statusCode < 200 || res.statusCode >= 300) {
            const msg = (json && (json.error || json.message)) || text || String(res.statusCode);
            reject(new Error(msg));
          } else resolve(json || {});
        });
      });
      request.on("error", (err) => { clearTimeout(timer); reject(err); });
      request.end(body ? JSON.stringify(body) : undefined);
    } catch (e) { reject(e); }
  });
}
const postJson = (url, body) => httpJson("POST", url, body);
const getJson  = (url) => httpJson("GET", url, null);

function normalizeOrder(resp) {
  const src = (resp && (resp.order || resp)) || {};
  const id = src.id || src.orderId || src.dbId || null;
  const invoiceId = src.invoiceId || src.invoice || src.invoice_id || null;
  const link = src.link || src.pageUrl || src.paymentLink || src.payment_url || src.url || null;
  return { id, invoiceId, link, ...src };
}

async function createOrder({ plan, machineId, forceNew }) {
  const raw = await postJson(`${HARD_BASE}/api/orders`, { plan, machineId, forceNew: !!forceNew });
  return normalizeOrder(raw);
}
async function refreshOrder(orderId) {
  const raw = await postJson(`${HARD_BASE}/api/orders/${encodeURIComponent(orderId)}/refresh`, {});
  return normalizeOrder(raw);
}
async function activateLicense({ machineId, orderId }) {
  return postJson(`${HARD_BASE}/api/license/activate`, { machineId, orderId });
}
async function pingApi() {
  try { return await getJson(`${HARD_BASE}/api/ping`); } catch (e) { return { ok:false, error: e.message || String(e) }; }
}

async function openPayment({ orderId, plan = "full-5", machineId, forceNew = true }) {
  const mid = machineId || computeMachineId();
  let order;
  if (forceNew) {
    order = await createOrder({ plan, machineId: mid, forceNew: true });
  } else if (orderId) {
    try { order = await refreshOrder(orderId); }
    catch { order = await createOrder({ plan, machineId: mid, forceNew: true }); }
  } else {
    order = await createOrder({ plan, machineId: mid, forceNew: true });
  }
  if (!order || !order.link) throw new Error("Server responded without a payment link (link/pageUrl/paymentLink).");

  try {
    const wins = BrowserWindow.getAllWindows();
    const serialized = JSON.stringify(order);
    await Promise.all(wins.map(w => w.webContents.executeJavaScript(
      `localStorage.setItem('license.order', ${JSON.stringify(serialized)});
       localStorage.setItem('LS_LICENSE_ORDER_JSON', ${JSON.stringify(serialized)}); true;`, true
    )));
  } catch {}

  const payUrl = `${order.link}${order.link.includes("?") ? "&" : "?"}t=${Date.now()}`;
  if (paymentWindow && !paymentWindow.isDestroyed()) {
    try { await paymentWindow.webContents.session.clearCache(); } catch {}
    try { paymentWindow.close(); } catch {}
    paymentWindow = null;
  }
  paymentWindow = new BrowserWindow({
    width: 560, height: 820, title: "Оплата ліцензії — Duna Billiard Club",
    autoHideMenuBar: true, resizable: true, show: true, modal: false,
    webPreferences: { sandbox: true, contextIsolation: true },
  });
  const sess = paymentWindow.webContents.session;
  try { await sess.clearCache(); } catch {}
  sess.webRequest.onBeforeSendHeaders((details, callback) => {
    const headers = { ...details.requestHeaders };
    headers["Cache-Control"] = "no-cache"; headers["Pragma"] = "no-cache";
    callback({ requestHeaders: headers });
  });
  paymentWindow.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: "deny" }; });
  paymentWindow.on("closed", () => { paymentWindow = null; });
  await paymentWindow.loadURL(payUrl);
  return { order };
}

// ---------- IPC ----------
function registerIpc() {
  // legacy sync (to silence warnings)
  ipcMain.on("app:getVersionSync", (event) => { try { event.returnValue = app.getVersion(); } catch { event.returnValue = "dev"; } });
  ipcMain.on("machine:getIdSync", (event) => { try { event.returnValue = computeMachineId(); } catch { event.returnValue = ""; } });

  // modern async
  ipcMain.handle("app:getVersion", async () => { try { return app.getVersion(); } catch { return "dev"; } });
  ipcMain.handle("machine:getId", async () => { try { return computeMachineId(); } catch { return ""; } });

  ipcMain.handle("license:ping", async () => { try { const res = await pingApi(); return { ok: true, res }; } catch (e) { return { ok:false, error: e.message || String(e) }; } });
  ipcMain.handle("license:openPayment", async (_evt, payload) => {
    try { const result = await openPayment(payload || {}); return { ok: true, ...result }; }
    catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  ipcMain.handle("license:refreshOrder", async (_evt, { orderId }) => {
    try { const order = await refreshOrder(orderId); return { ok: true, order }; }
    catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  ipcMain.handle("license:activate", async (_evt, { machineId, orderId }) => {
    try { const result = await activateLicense({ machineId, orderId }); return { ok: true, ...result }; }
    catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  ipcMain.handle("license:applyJwt", async (_evt, { jwt, meta } = {}) => {
    try {
      if (!jwt || typeof jwt !== "string" || jwt.length < 40) throw new Error("Invalid license token");
      const token = writeLicenseToken(jwt);
      // persist meta to license.json
      try {
        const cur = JSON.parse(fs.readFileSync(LIC_JSON,"utf-8"));
        const next = { ...cur, meta: {
          plan: meta?.plan || cur?.meta?.plan,
          mode: meta?.mode || cur?.meta?.mode,
          tablesLimit: Number(meta?.tablesLimit || cur?.meta?.tablesLimit || 0) || undefined,
          expiresAt: meta?.expiresAt || cur?.meta?.expiresAt
        }};
        fs.writeFileSync(LIC_JSON, JSON.stringify(next,null,2), "utf-8");
      } catch {}
      const wins = BrowserWindow.getAllWindows();
      await Promise.all(wins.map(async (w) => {
        try { await w.webContents.executeJavaScript(`localStorage.setItem('license.ok','1'); true;`, true); } catch {}
      }));
      return { ok: true };
    } catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  ipcMain.handle("license:getStatus", async () => {
    try {
      const jwt = readLicenseToken();
      const active = !!jwt;
      let mode, tier, tablesLimit, expiresAt, daysLeft, plan;
      if (jwt){
        const payload = decodeJwtPayload(jwt) || {};
        mode = payload.mode || payload.type || (payload.sub ? "sub" : undefined);
        tier = payload.tier || payload.plan || undefined;
        plan = payload.plan || payload.tier || undefined;
        const exp = Number(payload.exp || payload.expires || 0);
        if (exp>0){ expiresAt = exp*1000; }
        tablesLimit = Number(payload.tablesLimit || payload.max_tables || payload.maxTables || payload.tables || 0) || undefined;
        if (expiresAt){ daysLeft = Math.max(0, Math.ceil((expiresAt - Date.now())/86400000)); }
      }
      try {
        const cur = JSON.parse(fs.readFileSync(LIC_JSON,"utf-8"));
        const meta = cur?.meta;
        if (meta){
          plan = meta.plan || plan;
          mode = meta.mode || mode;
          tablesLimit = Number(meta.tablesLimit || tablesLimit || 0) || tablesLimit;
          expiresAt = meta.expiresAt || expiresAt;
          if (expiresAt){ daysLeft = Math.max(0, Math.ceil((new Date(expiresAt).getTime() - Date.now())/86400000)); }
        }
      } catch {}

      const wins = BrowserWindow.getAllWindows();
      await Promise.all(wins.map(async (w) => {
        try { await w.webContents.executeJavaScript(active ? "localStorage.setItem('license.ok','1'); true;" : "localStorage.removeItem('license.ok'); true;", true); } catch {}
      }));
      if (!active) return { ok: false, active: false, reason: "no_license" };
      if (mode === "sub" && expiresAt && Date.now() > new Date(expiresAt).getTime()){
        return { ok: false, active: false, reason: "expired", mode, tier, plan, tablesLimit, expiresAt, daysLeft:0 };
      }
      return { ok: true, active: true, mode, tier, plan, tablesLimit, expiresAt, daysLeft, jwt };
    } catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  ipcMain.handle("license:clearOrder", async () => {
    try {
      const wins = BrowserWindow.getAllWindows();
      await Promise.all(wins.map(w => w.webContents.executeJavaScript(
        `localStorage.removeItem('license.order'); localStorage.removeItem('licenseOrder'); localStorage.removeItem('LS_LICENSE_ORDER_JSON'); sessionStorage.removeItem('license.order'); true;`, true
      )));
      return { ok: true };
    } catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  ipcMain.handle("license:getApiBase", async () => ({ ok: true, base: HARD_BASE }));
  ipcMain.handle("license:setApiBase", async () => ({ ok: true, base: HARD_BASE }));
  ipcMain.handle("license:activated", async () => {
    try {
      const wins = BrowserWindow.getAllWindows();
      await Promise.all(wins.map(async (w) => {
        try { await w.webContents.executeJavaScript("try { localStorage.setItem('license.ok','1'); } catch(e) {} ; location.reload(); true;", true); } catch {}
      }));
      return { ok: true };
    } catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  ipcMain.handle("license:deactivate", async () => {
    try {
      try { fs.unlinkSync(LIC_JSON); } catch {}
      try { fs.unlinkSync(LIC_JWT); } catch {}
      const wins = BrowserWindow.getAllWindows();
      await Promise.all(wins.map(async (w) => {
        try {
          await w.webContents.session.clearStorageData({
            storages: ["localstorage","indexeddb","websql","serviceworkers","cachestorage"],
          });
          await w.webContents.executeJavaScript("localStorage.removeItem('license.ok'); true;", true);
        } catch {}
      }));
      return { ok: true };
    } catch (err) { return { ok: false, error: err.message || String(err) }; }
  });
  console.log("[main] IPC registered v33 (base:", HARD_BASE, ")");

  // === PRINT: опціонально зареєструвати ESC/POS (якщо є escpos.cjs)
  try { if (registerEscposPrinting) registerEscposPrinting(ipcMain); }
  catch (e) { console.warn("[print] ESC/POS register failed:", e?.message || e); }
}

// ---------- window ----------
function createMainWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 800, show: false, autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, "preload.cjs"), contextIsolation: true, nodeIntegration: false },
  });

  // === PRINT: додатковий preload (window.receipt + можливий window.escpos)
  try {
    const prev = (win.webContents.session.getPreloads ? win.webContents.session.getPreloads() : []);
    win.webContents.session.setPreloads([ ...prev, path.join(__dirname, "preload_receipt.cjs") ]);
  } catch (e) {}

  win.once("ready-to-show", () => win.show());
  if (isDev) win.loadURL(process.env.VITE_DEV_SERVER_URL);
  else win.loadFile(path.join(__dirname, "../dist/index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http")) { shell.openExternal(url); return { action: "deny" }; }
    return { action: "allow" };
  });

  // === PRINT: реєстрація HTML-друку під це вікно
  try { registerReceiptPrinting(win); } catch (e) { console.warn("[print] registerReceiptPrinting failed:", e?.message || e); }

  return win;
}

// ---------- bootstrap ----------
app.whenReady().then(() => {
  registerIpc();
  mainWindow = createMainWindow();
  const syncLocal = async () => {
    const has = !!readLicenseToken();
    const js = has ? "try{localStorage.setItem('license.ok','1');}catch(e){}; true;" : "try{localStorage.removeItem('license.ok');}catch(e){}; true;";
    try { await mainWindow.webContents.executeJavaScript(js, true); } catch {}
  };
  mainWindow.webContents.on("dom-ready", syncLocal);
  mainWindow.webContents.on("did-finish-load", syncLocal);
  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) { mainWindow = createMainWindow(); } });
});
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
