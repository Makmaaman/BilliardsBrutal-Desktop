// src/services/print.js
// Простий ESC/POS TCP друк або "mock" у файл

export async function printReceipt(printerIP, payload, mock=true){
  if (mock || !printerIP) {
    // зберегти у файл (в браузері — як data URL/завантаження)
    const blob = new Blob([typeof payload === "string" ? payload : String(payload||"")], { type:"text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().replace(/[:T]/g,"-").slice(0,19);
    a.href = url; a.download = "receipt_" + stamp + ".txt";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=> URL.revokeObjectURL(url), 2000);
    return { ok:true, mock:true };
  }

  // Якщо є IPC-міст до Node — краще друкувати там.
  try {
    if (window?.printer?.printRaw) {
      const res = await window.printer.printRaw({ ip: printerIP, raw: String(payload||"") });
      return res || { ok:true };
    }
  } catch {}

  // Без містка — можна спробувати HTTP-мікросервіс принтера, якщо є
  // або показати помилку:
  throw new Error("Прямий друк неможливий: немає нативного містка до принтера.");
}

// ================= Формування чеку =================

function safe(s){ return String(s||"").replace(/\s+/g," ").trim(); }
function two(n){ return String(n).padStart(2,"0"); }
function fmtHMS(ms){
  const t = Math.max(0, Number(ms)||0);
  const h = Math.floor(t/3_600_000);
  const m = Math.floor((t%3_600_000)/60_000);
  const s = Math.floor((t%60_000)/1000);
  return `${two(h)}:${two(m)}:${two(s)}`;
}
function m2(v){ return Number(v||0).toFixed(2); }

export function escposReceipt(data){
  const {
    tableName,
    tableNo,
    totalMs = 0,
    tableAmount = 0,
    rentalAmount = 0,
    rentalItems = [],
    currency = "UAH",
    tariffRate,
    closedAt = Date.now(),
  } = data || {};

  const curSign = (String(currency).toUpperCase() === "UAH") ? "₴" : currency;

  const total = Number(tableAmount) + Number(rentalAmount);

  const lines = [];
  lines.push("================================");
  lines.push("     БІЛЬЯРДНИЙ КЛУБ \"DUNA\"     ");
  lines.push("================================");
  lines.push("");

  const label = (tableNo !== undefined && tableNo !== null)
    ? `Ви грали за столом № ${tableNo}`
    : `Ви грали: ${safe(tableName || "—")}`;
  lines.push(label);
  lines.push("");

  lines.push("Час гри: " + fmtHMS(totalMs));
  lines.push("");

  // Розбивка
  lines.push("Світло:   " + m2(tableAmount) + " " + curSign);
  if (rentalItems && rentalItems.length) {
    lines.push("");
    lines.push("Оренда київ:");
    for (const it of rentalItems) {
      const rate = m2(it.rate);
      const hrs  = (it.hoursRaw != null ? it.hoursRaw : it.hours || 0);
      const hrsTxt = Number(hrs).toFixed(2); // 2 знаки у відображенні
      const tot  = m2(it.total);
      lines.push(`- ${safe(it.playerName)}: ${safe(it.cueName)} + ${rate} грн/год × ${hrsTxt} = ${tot} грн`);
    }
    lines.push("Сума за кий: " + m2(rentalAmount) + " " + curSign);
  } else {
    lines.push("Оренда київ: —");
  }

  lines.push("");
  lines.push("Сума:     " + m2(total) + " " + curSign);
  lines.push("");

  const dt = new Date(closedAt);
  lines.push("Закрито: " + dt.toLocaleString());
  if (tariffRate != null) lines.push("Тариф:   " + Number(tariffRate||0) + " грн/год");
  lines.push("Дата чеку: " + dt.toLocaleDateString());
  lines.push("");
  lines.push("Дякуємо за візит!");

  return lines.join("\n");
}
