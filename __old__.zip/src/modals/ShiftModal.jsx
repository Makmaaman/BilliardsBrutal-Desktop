import React from "react";
import ModalShell from "../components/ModalShell";
import Kpi from "../components/Kpi";
import { fmtDur, money } from "../utils/format";

export default function ShiftModal({ onClose, shift, openShift, closeShift, stats, summarize }) {
  // ---- helpers for LS ----
  const dayKey = (ts) => new Date(ts).toISOString().slice(0, 10);
  const readDay = (day) => {
    try { return JSON.parse(localStorage.getItem(`stats:day:${day}`) || "{}"); } catch { return {}; }
  };
  const listByShiftForDay = (shiftObj) => {
    if (!shiftObj) return [];
    const day = dayKey(shiftObj.openedAt || Date.now());
    const bucket = readDay(day);
    return Object.values(bucket).filter(r => r && r.shiftId === shiftObj.id);
  };

  const curShiftReceipts = shift ? listByShiftForDay(shift) : [];
  const nowTotals = shift
    ? (typeof summarize === "function"
        ? summarize(curShiftReceipts)
        : summarizeDefault(curShiftReceipts))
    : null;

  return (
    <ModalShell
      title="Зміна"
      onClose={onClose}
      footer={
        <div className="flex justify-end gap-2">
          {!shift && (
            <button className="h-9 px-4 rounded-lg bg-emerald-600 text-white" onClick={openShift}>
              Відкрити зміну
            </button>
          )}
          {shift && (
            <button className="h-9 px-4 rounded-lg bg-rose-600 text-white" onClick={closeShift}>
              Закрити зміну
            </button>
          )}
          <button className="h-9 px-4 rounded-lg bg-slate-800 text-white" onClick={onClose}>
            Готово
          </button>
        </div>
      }
    >
      {!shift ? (
        <div className="text-sm text-slate-600">Зміна не відкрита.</div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-xl ring-1 ring-slate-200 px-4 py-3 bg-white">
            <div className="text-sm"><b>ID:</b> {prettyShiftLabel(shift)}</div>
            <div className="text-sm">
              <b>Відкрито:</b> {new Date(shift.openedAt).toLocaleString()} • {shift.openedBy}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-3">
            <Kpi title="Нараховано (поточна зміна)" value={money(nowTotals?.totalAmount || 0)} />
            <Kpi title="Час (поточна зміна)" value={fmtDur(nowTotals?.totalMs || 0)} />
            <Kpi title="Ігор (поточна зміна)" value={nowTotals?.count || 0} />
          </div>
        </div>
      )}
    </ModalShell>
  );
}

/* ---------- локальні підрахунки ---------- */
function summarizeDefault(recs) {
  let totalAmount = 0, totalMs = 0, count = 0;
  for (const r of recs || []) {
    const ms = Array.isArray(r.intervals)
      ? r.intervals.reduce((s, iv) => s + ((iv.end ?? r.finishedAt) - (iv.start || r.startedAt || r.finishedAt)), 0)
      : Math.max(0, (r.finishedAt || 0) - (r.startedAt || 0));
    totalAmount += Number(r.amount || 0);
    totalMs += ms;
    count += 1;
  }
  return { totalAmount, totalMs, count };
}

/* ---------- красивий ярлик зміни ---------- */
function prettyShiftLabel(shift) {
  try {
    const day = new Date(shift?.openedAt || Date.now()).toISOString().slice(0, 10);
    const key = `stats:day:${day}`;
    let bucket = {};
    try { bucket = JSON.parse(localStorage.getItem(key) || "{}"); } catch {}

    // зберемо першу появу кожної зміни
    const firstByShift = new Map();
    for (const r of Object.values(bucket)) {
      if (!r?.shiftId) continue;
      const ts = r.finishedAt ?? r.ts ?? 0;
      if (!firstByShift.has(r.shiftId) || firstByShift.get(r.shiftId) > ts) {
        firstByShift.set(r.shiftId, ts);
      }
    }
    const ordered = Array.from(firstByShift.entries()).sort((a,b)=>a[1]-b[1]).map(([id])=>id);
    let seq = ordered.indexOf(shift.id);
    seq = seq >= 0 ? seq + 1 : ordered.length + 1;

    if (Number.isFinite(shift?.seq)) seq = Math.max(seq, Number(shift.seq) || 1);
    return `${day} • №${String(seq).padStart(2, "0")}`;
  } catch {
    return String(shift?.id || "");
  }
}
